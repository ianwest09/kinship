import { createKinshipApiApp } from '../server/apiRouter.js';

// Vercel Serverless Function entrypoint handling all /api/* endpoints
const app = createKinshipApiApp();

export default app;
